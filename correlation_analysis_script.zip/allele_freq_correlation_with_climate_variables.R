# Load packages 

library(ggplot2)

# Import data 

allefreq_temp_dat <- read.csv("allele_freq_climatic_variable_v2.csv", sep = ",")


# Split the data frame into subsets based on the Position variable

subsets <- split(allefreq_temp_dat, allefreq_temp_dat$Position)

cor_result <- data.frame(position = numeric(), correlation = numeric(), p_value = numeric(), method = character(), refugia = character())

index <- 0   

# Run the correlation analysis in a loop for the max temperature variable and allele frequency

for (i in subsets) {  
  index <- index + 1  
  print(index)
  temp_shap_test <- shapiro.test(i$max_temperature)
  allefreq_shap_test <- shapiro.test(i$allele_frequency)
  if (temp_shap_test$p.value > 0.05 && allefreq_shap_test$p.value > 0.05){
    cor_loop_pearson <- cor.test(i$max_temperature, i$allele_frequency, method = 'pearson')
    cor_result[index, 2] <- cor_loop_pearson$estimate 
    cor_result[index, 1] <- unique(i$Position) 
    cor_result[index, 3] <- round(cor_loop_pearson$p.value, 4) 
    cor_result[index, 4] <- "Pearson" 
    cor_result[index, 5] <- unique(i$Refugia)
  } else { 
    cor_loop_spearman <- cor.test(i$max_temperature, i$allele_frequency, method = 'spearman') 
    cor_result[index, 2] <- cor_loop_spearman$estimate 
    cor_result[index, 1] <- unique(i$Position)
    cor_result[index, 3] <- round(cor_loop_spearman$p.value, 4)
    cor_result[index, 4] <- "Spearman" 
    cor_result[index, 5] <- unique(i$Refugia)
    }
} 

# Save file

write.csv(cor_result, file = "all_correlations_per_position_max_temperature.csv")
  
    


                             