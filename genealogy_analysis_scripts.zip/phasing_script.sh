#!/bin/bash

for name in $(cat outlier_vcfgz_filenames.txt);  

do

java -Xmx16g -jar beagle.19Apr22.7c0.jar gt=${name}.vcf.gz out=likelihood_phased_${name}  nthreads=18 

done
