#!/bin/bash  

# Label the haplotype with the /R character if  it contains the reference allele in one of the outlier loci. Label the the haplotype with the /A character if it contains the alternative allele in one of the outlier loci. If the haplotype contains two different alternative alleles in the outlier loci, then label it with /A to represent one of the alternative alleles and label it with /E to represent the other alternative allele.  

for fasta in $(cat fasta_filenames_phased_sorted.txt); do    
	
		sed -E -i '/0\|0|0\|1|0\|2/ { s/-0/-0\/R/g }' $fasta 
		sed -E -i '/0\|0|1\|0|2\|0/ { s/-1/-1\/R/g }' $fasta   
		sed -E -i '/1\|1|1\|0|1\|2/ { s/-0/-0\/A/g }' $fasta  
		sed -E -i '/1\|1|0\|1|2\|1/ { s/-1/-1\/A/g }' $fasta  
		sed -E -i '/2\|1|2\|0|2\|2/ { s/-0/-0\/E/g }' $fasta 
		sed -E -i '/1\|2|0\|2|2\|2/ { s/-1/-1\/E/g }' $fasta     
done
