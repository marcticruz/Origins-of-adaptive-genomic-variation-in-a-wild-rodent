#!/bin/bash 

#Transfer the locality information in the pop file france_netherlands_slovakia_czech_heslington_lizard_maud_pop4.txt into the fasta header of 1074 fasta files each containing 140 fasta headers

for file in $(cat fasta_filenames_phased_sorted.txt); do

        for name in $(cat france_netherlands_slovakia_czech_heslington_lizard_maud_pop4.txt); do

        id=$(echo $name | cut -d ":" -f 1)
        locality=$(echo $name | cut -d ":" -f 2) 

        sed -E -i "s/$id/${id}_${locality}/g" $file

        done 
done


