#!/bin/bash

for name in $(cat fasta_filenames_phased_sorted.txt);  

do

sed -i 's/:/_/' $name

sed -i 's/_1$/-1/' $name  

sed -i 's/_0$/-0/' $name  

 
done
