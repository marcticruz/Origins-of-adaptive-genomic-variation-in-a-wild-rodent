#!/bin/bash

for name in $(cat Outliers_QvalPcadapt_Qval_pRDA_95Fst.txt); 

do  

    scaffold=$(echo $name | cut -d ":" -f 1)
    position=$(echo $name | cut -d ":" -f 2)

    upstream=$((position + 50000)) 
    downstream=$((position - 50000)) 
	
    if [[ $downstream -lt 0 ]]; then
    /usr/bin/bcftools-1.9/bcftools view france_netherlands_slovakia_czech_heslington_maud_lizard_allsites_noduplicates.vcf.gz   -r ${scaffold}:1-${upstream} -o france_netherlands_slovakia_czech_heslington_maud_lizard_outlier_${position}_${scaffold}_1-${upstream}.vcf.gz -O z  
    
    else  

    /usr/bin/bcftools-1.9/bcftools view france_netherlands_slovakia_czech_heslington_maud_lizard_allsites_noduplicates.vcf.gz   -r ${scaffold}:${downstream}-${upstream} -o france_netherlands_slovakia_czech_heslington_maud_lizard_outlier_${position}_${scaffold}_${downstream}-${upstream}.vcf.gz -O z     

    fi  
 
done



