#!/bin/bash

for name in $(cat reference_fasta_files_list.txt); do  

#sed -i 's/[0-9]* //g' $name  

sed -i 's/\:[0-9]*-[0-9]*//g' $name

done
