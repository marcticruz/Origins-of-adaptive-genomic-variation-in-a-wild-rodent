#!/bin/bash

while read name reference; do

vcf2fasta -f ./${reference} -p phased_fasta_${name} ./${name}

done < <(paste phased_filenames_sorted_vcfgz.txt reference_fasta_files_list_sorted.txt)
