#!/bin/bash 


#create new fasta files that have file names in which ; is replaced by _  so they can run in raxml without an error. Raxml do not accept ; in the file name of input files

for file in phased*";"*.fasta; 

do

    newname="${file//;/_}"
    cp "$file" "./$newname"

done  

# Execute raxml in a loop with each iteration of the loop using one of the 1074 fasta files as input. 


for name in $(cat phased_fasta_renamed_sorted.txt); 

do

   raxmlHPC -f d -N 30 -m GTRCAT -s $name -n $name -p 231
 
done   
