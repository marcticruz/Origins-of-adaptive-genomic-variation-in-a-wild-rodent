#!/bin/bash

#Extract only the genotype information and sample ID information of a vcf file contain a single outlier locus. Each sample ID is associated with its respective genotype for a given individual

for name in $(cat onesite_vcfgz_filenames.txt);  

do

/usr/bin/bcftools-1.9/bcftools query -f '%CHROM\t%POS\t%REF\t%ALT[\t%SAMPLE=%GT]\n' $name > genotypes_and_ids_${name} 

done
