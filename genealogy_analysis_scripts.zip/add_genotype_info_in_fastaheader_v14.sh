#!/bin/bash

counter=0
while read fasta; do 
	
	counter=0

	while read line; do   
	              		
			id=$(echo $line | cut -d ":" -f 1)
                 	
			genotype=$(echo $line | cut -d ":" -f 2) 
               	       
			counter=$((counter + 1)) 
			
			sed -r -i s/$id/${id}_${genotype}/g $fasta 
			
			sed -r -i s/\;/_/g $fasta 
 
		        if [[ "$counter" -eq "70" ]]; then
           		 sed -i '1,70d' all_genotypes_ids_sorted_outliers.txt 
			 break
			fi	
	
	done < all_genotypes_ids_sorted_outliers.txt

done < fasta_filenames_phased_sorted.txt
