#!/bin/bash

for name in $(cat reference_fasta_files_list.txt);

do

samtools faidx $name 

bwa index $name  

java -jar ./picard.jar CreateSequenceDictionary R=${name} O=${name}.dict 

done

