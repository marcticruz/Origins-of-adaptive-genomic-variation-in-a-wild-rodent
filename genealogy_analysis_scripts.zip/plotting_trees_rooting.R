#load packages
library(treeio)
library(ggtree)
library(ape)  
library(gsubfn)
library(ggplot2)


# read the lines of a file that cotain a list of newick file names

lines <- readLines(file("all_trees_files.txt"))    


# Read all the newick files, set the outgroup, removed unwanted charaters from tip label, give different colors for tip labels representing haplotypes that contain the reference or the alternative allele in the outlier locus

for (file in lines){
  
  tree <- read.tree(file)       
  
  outgroup <- grep("1830_S45*", tree$tip.label)   
  outgroup_label <- tree$tip.label[outgroup[1]]
  
  tree <- root(tree, outgroup = outgroup_label, resolve.root = TRUE)

  
  
  tree$tip.label <- gsub("_\\d\\|\\d", "", tree$tip.label, fixed = FALSE)  
  
  tree$tip.label <- gsub("EU|[0-9]+_S[0-9]+_", "", tree$tip.label, fixed = FALSE)  
  
  tree$tip.label <- gsub("_Scaffold_[0-9]+_HRSCAF_[0-9]+-\\d", "", tree$tip.label, fixed = FALSE)  
  
 
  
  dd <-data.frame(taxa=c("France_Western/R", "Netherlands_Western/R", "Czechia_Carpathian/R", "Slovakia_Carpathian/R", "Lizard/R", "Maud/R", "Heslington/R", "SilaGrande_Calabrian/R", "France_Western/A",  "Netherlands_Western/A", "Slovakia_Carpathian/A", "Czechia_Carpathian/A", "Maud/A", "Lizard/A", "Heslington/A", "SilaGrande_Calabrian/A"), 
                  place=c("s1", "s1", "s1", "s1", "s1", "s1", "s1", "s1", "s2", "s2", "s2", "s2", "s2", "s2", "s2", "s2"))
  
  
  
  p <- ggtree(tree, layout = "circular", branch.length = "none")
  
  p <- p %<+% dd + geom_tiplab(aes(color=place), size = 2) + theme(legend.position="none")
  
  ggsave(p, file=paste0(file,".png"), width = 28, height = 20, units = "cm")
  
}

dev.off()
