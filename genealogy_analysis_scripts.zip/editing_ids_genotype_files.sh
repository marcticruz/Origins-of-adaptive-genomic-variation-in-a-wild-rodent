#!/bin/bash

#Remove all the unecessary characters from the genotype_ids_files and only keep ID number and genotype information.The should layout the data like this ID:genotype

for name in $(cat genotypes_and_ids_vcfgz_filenames_sorted.txt); 

do

sed -i 's/Scaffold_[0-9]*\;HRSCAF_[0-9]*\t[0-9]*\t[A-Z]\t[A-Z]\t//' $name

sed -i 's/Scaffold_[0-9]*\;HRSCAF_[0-9]*\t*\t*\t*\t//' $name

sed -i 's/[0-9]*\t[A-Z]\t[A-Z]\,[A-Z]\t//' $name

sed -i 's/[0-9]*\t[A-Z]\t\.\t//' $name

sed -i 's/[0-9]*\t\.\t[A-Z]\t//' $name   

sed -i 's/\t/\n/g' $name  

sed -i 's/=/:/g' $name 

done
