# Scripts for gene genealogy analysis  

All the bash scripts can be executed using the command bash scriptname.sh  

extract_regions_bcftools_v4.sh: extracts 50 kb upstream and downstream each of the 1074 outlier loci. Requires bcftools software, a file (Outliers_QvalPcadapt_Qval_pRDA_95Fst.txt) with the indexes for each outlier locus, and vcf.gz file. Generates 1074 vcf.gz files each containing 140 haplotypes of 101kb.  

phasing_script.sh: phases each 1074 vcf.gz file containing 140 haplotypes of 101Kb.   


bcftools_extracting_one_site_v2.sh: takes 1074 phased vcf.gz files with 101kb sites and extract just only the outlier locus and it stores in another vcf.gz file that contain only the alleles in outlier locus.Requires bcftools software, a file with a list of names of the phased vcf.gz file (phased_filenames_sorted_vcfgz.txt), a file (phased_outliers_coordinates_sorted_list.txt) with the indexes for each outlier locus and vcf.gz files. Generates 1074 vcf.gz files each containing only the alleles in the outlier locus. 

genotype_from_phase_onesite_v2.sh: Extract  the genotype information and sample ID information of a vcf file that contain a single outlier locus. Each sample ID is associated with its respective genotype for a given individual. Requires a file (onesite_vcfgz_filenames.txt) with the names of the vcf.gz files that contain only the alleles in the outlier loci. 

editing_ids_genotype_files.sh: remove all the characters that are not of interest from each of 1074 vcf.gz file containing only the alleles in the outlier locus. Requires a file (genotypes_and_ids_vcfgz_filenames_sorted.txt) with a list of names of vcf.gz files containing only the alleles in the outlier locus. Edits 1074 vcf.gz files in such a way that the  data is laid out following the structure ID:genotype. Those files will be used later in the pipeline.

samtool_faidx_reference_subset_loop.sh: extract the regions of the reference of the genome of the bank vole that corresponds to each of the 1074 haplotypes with 101kb that contain one of the outlier locus to use as a reference to convert the phased vcf.gz with the 101kb haplotypes into fasta files in a later step of the pipeline. Requires samtools software, a file with a list of index of where each of 1074 outliers loci is within 101kb stretchs of the reference genome, and the reference genome of the bank vole in a fasta file. Generates 1074 reference fasta files that will be used to convert pashed vcf.gz files into phased fasta files. 

editing_the_header_of_referencemakere_reference_file.sh: remove unwanted characters from the fasta headers of the reference files. This need to be done to approprietaly convert vcf.gz files into fasta files in the later steps of this pipeline. 

samtools_index_loop.sh: indexes each of the 1074 reference fasta files. Requires, samtools, bwa, picard, a file (reference_fasta_files_list.txt) with a list of names of the reference fasta files. 

vcf2fasta_loop3.sh: converts 1074 phased vcf.gz files each containing 140 haplotypes with length of 101kb into phased fasta files. Requires vcf2fasta software, a file with a list of names of the phased vcf.gz file (phased_filenames_sorted_vcfgz.txt) and a file with a list of names of the reference fasta files (reference_fasta_files_list_sorted.txt). Generates 150,360 phased fasta files each containing a single haplotype with length of 101kb. 

merge_phased_files_loop.sh: merges 150,360 phased fasta files into 1074 fasta files each containing 140 phased haplotypes based on the position of the genome they are supposed to be. Requires a file (positions_scaffold_names_file_sorted.txt) with the indexes of the position of the genome the outlier loci is supposed to be.  

put_localities_names_into_fastaheader.sh: Transfer the locality information in a pop file (france_netherlands_slovakia_czech_heslington_lizard_maud_pop.txt) into each of the 140 fasta headers in the 1074 fasta files. Requires a pop file and a file (fasta_filenames_phased_sorted.txt) with the list of names of the phased fasta files.  

merging_genotypes_files.sh: transfer the ID:genotype information in 1074 vcf.gz files into a single text file (all_genotypes_ids_sorted_outliers.txt) that will be used later in the pipeline to include the genotype information into the fasta headers of the 1074 phased fasta files. Requires a file (genotypes_and_ids_vcfgz_filenames_sorted.txt) with the names of the vcf.gz files that contain only ID:genotype information. 

add_genotype_info_in_fastaheader_v14.sh: transfer the genotype information of the outlier loci available in the file "all_genotypes_ids_sorted_outliers.txt" to the fasta headers of the phased fasta files. The genotype are coded as 0|0 or 0|1 or 1|1 or 1|0 depending on whether the haplotypes pairs - haplotype 1 left side of the bar or haplotype 2 right side of the bar - has the reference (0) or the alternative allele (1) in the outlier loci. In the fasta headers the haplotype 1 is labeled with -0 and the haplotype 2 is labeled with -1. In the vcf.gz files the reference allele is coded as 0 and the alternative allele is coded as 1. Requires a file (all_genotypes_ids_sorted_outliers.txt) with ID:genotype information and a file with the names of the phased fasta files 

identifying_alternative_reference_in_samples_v3.sh: label the haplotype with the /R character if  it contains the reference allele in one of the outlier loci. Label the the haplotype with the /A character if it contains the alternative allele in one of the outlier loci. If the haplotype contains two different alternative alleles in the outlier loci, then label it with /A to represent one of the alternative alleles and label it with /E to represent the other alternative allele. Requires a file (fasta_filenames_phased_sorted.txt) with a list of names of the phased fasta files.  

edit_fasta_files.sh: remove characters from the fasta files that might cause problems in the folowing steps of the pipeline. Requires a list of phased fasta files. 

raxml_analysis_loop_v6.sh: Execute raxml in a loop with each iteration of the loop using one of the 1074 fasta files as input. Requires a raxml and a file (phased_fasta_renamed_sorted.txt) with the names of the edited phased fasta files.  

plotting_trees_rooting.R: Read all the 1074 newick files generated by RAxML, set the outgroup, removed unwanted charaters from tip label, give different colors for tip labels representing haplotypes that contain the reference or the alternative allele in the outlier locus.
