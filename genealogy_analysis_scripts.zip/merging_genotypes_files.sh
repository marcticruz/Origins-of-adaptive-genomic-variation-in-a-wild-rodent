#!/bin/bash 

for file in $(cat genotypes_and_ids_vcfgz_filenames_sorted.txt); do    

cat $file >> all_genotypes_ids_sorted_outliers.txt  

done

