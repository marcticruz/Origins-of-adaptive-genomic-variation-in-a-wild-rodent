#!/bin/bash 

for name in $(cat positions_scaffold_names_file_sorted.txt);   

do  

cat phased_fasta_phased_france_netherlands_slovakia_czech_heslington_maud_lizard_outlier*${name}*.fa > phased_fasta_phased_france_netherlands_slovakia_czech_heslington_maud_lizard_outlier_${name}.fasta  

done  
