#!/bin/bash

#generate a reference file containing the outlier loci for all the 1074 haplotypes

for name in $(cat reference_maker_interval_file.txt);

do

    scaffold=$(echo $name | cut -d ":" -f 1)
    interval=$(echo $name | cut -d ":" -f 2)   

    downstream=$(echo $interval | cut -d "-" -f 1)  
    upstream=$(echo $interval | cut -d "-" -f 2)  

    
    position=$(echo $scaffold | cut -d "|" -f 1)  
    scaffold2=$(echo $scaffold | cut -d "|" -f 2)     
	
    samtools faidx ./bank_vole_11Jun2018_KbcOz2.fasta ${scaffold2}:${position}-${position}  > ./genealogy_script/reference_${scaffold}_${downstream}-${upstream}.fasta
	
done
