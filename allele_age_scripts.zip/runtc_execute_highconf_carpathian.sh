#!bin/bash


for position in $(cat highconf_carpathian_positions.txt); 

do 

 

python runtc.py highconf_carpathian_${position}.vcf.gz --k-all --rec 6e-9 --mut 2.2e-9 > highconf_carpathian_kall_mut2.2e-9_rec6e-9_${position}_tc 

grep $position highconf_carpathian_kall_mut2.2e-9_rec6e-9_${position}_tc >> highconf_carpathian_position_tc_values
  

done 
