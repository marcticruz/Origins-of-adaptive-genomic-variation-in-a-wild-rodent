#!bin/bash

for position in $(cat highconf_britain_positions.txt); 

do 

python runtc.py highconf_britain_${position}.vcf.gz --k-all --rec 6e-9 --mut 2.2e-9 > highconf_britain_kall_mut2.2e-9_rec6e-9_${position}_tc 

grep $position highconf_britain_kall_mut2.2e-9_rec6e-9_${position}_tc >> highconf_britain_position_tc_values
  
done 
