# Scripts for batch execution of the runtc software.  

All the scripts can be executed as bash scriptname.sh. Requires the software runtc and files (highconf_britain_positions.txt, highconf_carpathian_positions.txt, highconf_western_positions.txt, highconf_widespread_positions.txt) with the indexes for the position of where outlier loci are supposed to be in the genome
