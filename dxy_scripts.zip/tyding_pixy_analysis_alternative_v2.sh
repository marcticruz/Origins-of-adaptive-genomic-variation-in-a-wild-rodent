#!/bin/bash

# run pixy

for name2 in $(cat alternative_concatenated_filenames.txt); do 

	interv=$(echo $name2 | cut -d "_" -f 17) 
	posi=$(echo $name2 | cut -d "_" -f 12)
        start=$(echo $interv | cut -d "-" -f 1)  
	end=$(echo $interv | cut -d "-" -f 2) 
	chrom1=$(echo $name2 | cut -d "_" -f 13) 
	chrom2=$(echo $name2 | cut -d "_" -f 14) 
	chrom3=$(echo $name2 | cut -d "_" -f 15) 
	chrom4=$(echo $name2 | cut -d "_" -f 16) 
 
        pixy --stats pi fst dxy --vcf ${name2}.vcf.gz --populations france_netherlands_slovakia_czech_heslington_lizard_maud_pop_for_pixy.txt --interval_start $start --interval_end $end --window_size 100000 --output_prefix alternative_chrom-${chrom1}-${chrom2}-${chrom3}-${chrom4}_pos-${posi}_interval-${start}-${end} 
		
done

