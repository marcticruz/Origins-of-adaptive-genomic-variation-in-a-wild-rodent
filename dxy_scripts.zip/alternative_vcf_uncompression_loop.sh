#!/bin/bash 

for name in $(cat alternative_concatenated_filenames.txt); do

gunzip ${name}.vcf.gz

done
