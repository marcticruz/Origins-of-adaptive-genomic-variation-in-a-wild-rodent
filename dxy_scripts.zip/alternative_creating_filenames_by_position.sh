#!/bin/bash

for name in $(cat vcfgz_filenames.txt); do 

posi=$(echo $name | cut -d "_" -f 10) 

#echo $posi 

ls alternative*S*_*${posi}*.vcf.gz > alternative_concatenated_${name}.txt 


done
