#!/bin/bash 

for naming in $(cat alternative_genotypes_and_separate_vcffilename.txt); do 
	
	geno=$(echo $naming | cut -d "/" -f 1) 
	name=$(echo $naming | cut -d "/" -f 2)

	
	if [ $geno == "1|0" ]; then 
		sed -i  's/0|0/0|./g' ${name}.vcf 
		sed -i  's/1|0/1|./g' ${name}.vcf   
		sed -i  's/0|1/0|./g' ${name}.vcf  
		sed -i  's/1|1/1|./g' ${name}.vcf 
	elif [ $geno == "0|0" ]; then 
		sed -i  's/0|0/.|./g' ${name}.vcf 
		sed -i  's/1|0/.|./g' ${name}.vcf
                sed -i  's/0|1/.|./g' ${name}.vcf
                sed -i  's/1|1/.|./g' ${name}.vcf 
	 elif [ $geno == "0|1" ]; then
                sed -i  's/0|0/.|0/g' ${name}.vcf
                sed -i  's/1|0/.|0/g' ${name}.vcf
                sed -i  's/0|1/.|1/g' ${name}.vcf
                sed -i  's/1|1/.|1/g' ${name}.vcf 
	fi 
done 	
