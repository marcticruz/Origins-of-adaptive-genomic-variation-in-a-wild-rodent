#!/bin/bash

for name in $(cat alternative_vcf_by_sample_filenames.txt); 

do 

posi=$(echo $name | cut -d "_" -f 13)

grep  ${posi} ${name}.vcf | grep GT | awk '{print $10}' >> alternative_genotypes_and_separate_vcffilename.txt # grep genotype in the outlier loci


sed -i '$s/$/ '${name}'/' alternative_genotypes_and_separate_vcffilename.txt #index genotype with the filename where the genotype is found. 

done
