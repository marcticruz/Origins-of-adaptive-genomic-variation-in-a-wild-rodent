#!/bin/bash

for name in $(cat genotypes_and_separate_vcffilename.txt); do 

name2=$(echo $name | cut -d "/" -f 2) 

echo $name2

/usr/bin/bcftools-1.9/bcftools index ${name2}.vcf.gz 

done  

for name in $(cat alternative_vcf_by_sample_filenames.txt); do

name2=$(echo $name | cut -d "/" -f 2)

echo $name2

tabix ${name2}.vcf.gz

done

for name in $(cat alternative_concatenated_filenames.txt); do

name2=$(echo $name | cut -d "/" -f 2)

#echo $name2

tabix ${name}.vcf.gz

done
