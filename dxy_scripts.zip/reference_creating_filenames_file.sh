#!/bin/bash

for num in $(cat bank_vole_loci_under_selection_chrom_positions.txt); do 

posi=$(echo $num | cut -d "-" -f 2)

ls reference*S*_*${posi}*.vcf >> reference_vcf_by_sample_filenames.txt  

done
