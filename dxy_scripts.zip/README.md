# Scripts for the dxy analysis  based only on the haplotypes that contain the reference allele in the outlier loci

All the bash scripts can be executed using the command bash scriptname.sh 

reference_separate_vcf_samples.sh: take 1074 vcf.gz each containing 140 phased haplotypes and generate 75,180 vcf files each containing 2 phased haplotypes. Requires bcftools, a file (vcffilenames.txt) with the names of the phased  vcf.gz files, a file with sample ids (sample_ids.txt).    

reference_creating_filenames_file.sh: create a file (reference_vcf_by_sample_filenames.txt) with the names of the 75,180 vcf files that contains a pair of haplotypes. Requires a file (bank_vole_loci_under_selection_chrom_positions.txt) with the indexes for the position of the genome where the outlier loci are supposed to be.  


reference_filenames_indexed_by_genotypes.sh: create a file (reference_genotypes_and_separate_vcffilename.txt) with the file names of the 75,180 vcf files each containing 2 phased haplotypes and index those files names with the genotype that is found in the outlier locus of the haplotypes. Requires (reference_vcf_by_sample_filenames.txt) a file with the names of the 75,180 vcf files 

get_reference_haplotypes_from_vcf.sh: exclude the haplotypes that have the altenartive allele in the outlier locus resulting in vcf files that contain only the haplotypes that have the reference allele in the outlier loci. Requires a file (reference_genotypes_and_separate_vcffilename.txt) with the file names of the 75,180 vcf files each containing 2 phased haplotypes and the genotype in the outlier loci of those haplotypes. 

reference_vcf_compression_loop.sh: compress the 75,180 vcf files into 75,180 vcf.gz files so we can merge them into 1074 vcf.gz files later in the pipeline. Requires a file (reference_genotypes_and_separate_vcffilename.txt) with the file names of the 75,180 vcf files each containing 2 phased haplotypes and the genotype in the outlier loci of those haplotypes. It also requires bcftools software. 

reference_index_loop_v2.sh: indexes 75,180 vcf.gz files so we can merge them into 1074 vcf.gz files later in the pipeline. Requires a file (reference_genotypes_and_separate_vcffilename.txt) with the file names of the 75,180 vcf files each containing 2 phased haplotypes and the genotype in the outlier loci of those haplotypes. 

reference_creating_filenames_by_position.sh: create txt files containing the names that will be necessary to merge the 75,180 vcf.gz files into 1074 .vcf.gz files later in the pipeline. Requires a file (vcfgz_filenames.txt) with the names of 1074 vcf.gz files 

reference_merging_vcfiles_by_position_and_samples.sh: merges the 75,180 vcf.gz files each containing only the haplotypes that have the reference allele in the outlier loci into 1074 vcf.gz files according to the position of the genome where the outlier loci is supposed to be. Requires a file (reference_concatenated_filenames.txt) that contains the information about where each haplotype is supposed to be in the genome. 

reference_vcf_uncompression_loop.sh: after the last merging step, characters that will cause problems later down the pipeline are introduced  in the vcf.gz files. This script uncompress 1074 vcf.gz files into 1074 vcf files so it is possible to replace the problematic characters with the appropriate characters in the the next step of the pipeline. Requires a file (reference_concatenated_filenames.txt) with the names of the vcf.gz files.  

reference_replacing_characters_loop.sh: replace the unwanted characters with the appropriate characters in 1074 vcf files that will make it possible to run the pixy software using a compressed and indexed version of these vcf files in the later steps of the pipeline. Requires a file (reference_concatenated_filenames.txt) with the names of the vcf files.  

reference_vcf_compression_loop.sh: compress 1074 edited vcf files into 1074 vcf.gz files. Requires a file (reference_concatenated_filenames.txt) with the names of the vcf files. 

reference_index_loop_v2.sh: indexes 1074 vcf.gz files. Requires a file (reference_concatenated_filenames.txt) with the names of the vcf files.  

tyding_pxy_analysis_reference_v2.sh: run the pixy software on 1074 vcf.gz files that contain only the haplotypes with the reference allele in the outlier loci. Requires pixy, a file  (reference_concatenated_filenames.txt) with the names of the vcf.gz files. 

# To run the pixy software using only the haplotypes containing the alternative allele in the outlier loci repeat all the steps above using the files with the label alternative in them.
