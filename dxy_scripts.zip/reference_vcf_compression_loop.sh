#!/bin/bash

for name in $(cat reference_genotypes_and_separate_vcffilename.txt); do

name2=$(echo $name | cut -d "/" -f 2)

bgzip ${name2}.vcf

done  


for name in $(cat reference_concatenated_filenames.txt); do


bgzip ${name}.vcf

done
