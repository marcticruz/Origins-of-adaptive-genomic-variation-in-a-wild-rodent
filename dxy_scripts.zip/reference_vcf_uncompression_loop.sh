#!/bin/bash 

for name in $(cat reference_concatenated_filenames.txt); do

gunzip ${name}.vcf.gz

done
