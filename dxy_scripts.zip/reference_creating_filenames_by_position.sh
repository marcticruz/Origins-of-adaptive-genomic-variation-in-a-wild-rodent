#!/bin/bash

for name in $(cat vcfgz_filenames.txt); do 

posi=$(echo $name | cut -d "_" -f 10)  

ls reference*S*_*${posi}*.vcf.gz > reference_concatenated_${name}.txt 


done
