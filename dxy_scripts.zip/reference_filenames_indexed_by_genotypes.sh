#!/bin/bash

for name in $(cat reference_vcf_by_sample_filenames.txt);do 

posi=$(echo $name | cut -d "_" -f 13)

grep  ${posi} ${name}.vcf | grep GT | awk '{print $10}' >> reference_genotypes_and_separate_vcffilename.txt # grep genotype in the outlier loci

sed -i '$s/$/ '${name}'/' reference_genotypes_and_separate_vcffilename.txt #index genotype with the filename where the genotype is found. 

done
