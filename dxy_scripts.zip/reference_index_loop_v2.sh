#!/bin/bash
  
for name in $(cat reference_genotypes_and_separate_vcffilename.txt); do

name2=$(echo $name | cut -d "/" -f 2)

tabix ${name2}.vcf.gz

done


for name in $(cat reference_concatenated_filenames.txt); do

tabix ${name}.vcf.gz

done
