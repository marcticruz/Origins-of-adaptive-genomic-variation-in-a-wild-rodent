#!/bin/bash 

for name in $(cat alternative_concatenated_filenames.txt); do

sed -i 's/\//|/g' ${name}.vcf

done
