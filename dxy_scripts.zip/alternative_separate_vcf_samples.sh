#!/bin/bash

for name in $(cat vcffilenames.txt); do
	for id in $(cat sample_ids.txt); do 
		/usr/bin//bcftools-1.9/bcftools view -s ${id} ${name}.vcf.gz -O v -o alternative_${id}_${name}.vcf 
	done 
done
