#!/bin/bash

for name in $(cat alternative_concatenated_filenames.txt ); 

do

/usr/bin/bcftools-1.9/bcftools merge --file-list ${name}.txt -o ${name}.vcf.gz -O z

done
