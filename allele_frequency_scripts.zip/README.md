#Scripts to execute the allele frequency analysis 

All the scripts can be executed as bash scriptname.sh 

bcftools_extracting_one_site_for_plink.sh: extract only the outlier loci from the whole genome and ouputs each loci on a separate vcf.gz file. Requires bcftools and a  file (Outliers_QvalPcadapt_Qval_pRDA_95Fst.txt) with the indexes of the positions where the outliers are in the genome. 

concat_vcf_bcf_files.sh: merge the separate vcf.gz files containing the outlier locus into a single vcf.gz that contain all the outlier loci. Requires bcftools and a file (onesite_plink_list.txt) containing the names of the separate vcf.gz files each containg a single outlier loci.  

plink2_analysis_v2.sh: executes plink to calculate the allele frequencies in the outlier loci. Requires a pop file (france_netherlands_slovakia_czech_heslington_lizard_maud_pop_for_plink.txt), a vcf.gz file with the outlier loci. 

