#!/bin/bash
 
for line in $(cat  Outliers_QvalPcadapt_Qval_pRDA_95Fst.txt); do

	scaffold=$(echo $line | cut -d ":" -f 1)
   	position=$(echo $line | cut -d ":" -f 2)
	#echo $file 
        #echo $scaffold  
        #echo $position    
	/usr/bin/bcftools-1.9/bcftools view france_netherlands_slovakia_czech_heslington_maud_lizard_allsites_noduplicates.vcf.gz -r ${scaffold}:${position} -o onesite_plink_${scaffold}_${position}.vcf.gz -O z
done
