/usr/bin/bcftools-1.9/bcftools concat --file-list  onesite_plink_list.txt -o  france_netherlands_slovakia_czech_heslington_maud_lizard_onesite_plink_concatenated.vcf.gz -O z --threads 25
